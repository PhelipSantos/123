class UserDTO {
    constructor({ id, email }) {
        this.id = id;
        this.email = email;
    }
}

module.exports = UserDTO;
