// app.js
const express = require("express");
const bodyParser = require("body-parser");
const UserController = require("./user/user.controller.js");
const PerfilController = require("./perfil/perfil.controller.js")
const app = express();
const port = 3000;

app.use(bodyParser.json()); // Para parsing de application/json

const userController = new UserController();

// Rotas para o CRUD de Usuário
app.post("/users", (req, res) => userController.createUser(req, res));
app.get("/users", (req, res) => userController.getAllUsers(req, res));
app.get("/users/:id", (req, res) => userController.getUserById(req, res));
app.put("/users/:id", (req, res) => userController.updateUser(req, res));
app.delete("/users/:id", (req, res) => userController.deleteUser(req, res));

app.post("/perfil",(req,res)=> PerfilController.createUser ) 

app.listen(port, () => {
  console.log(`Servidor rodando em http://localhost:${port}`);
});

{user_id}/addresses_id/ ;post 

{
  "profile_endereco"; "Endereço",
  "profile_cidade"; "Cidade",
  "country_id"; "ID do País"
  }

  {user_id}/addresses/ ;{address_id} ;delet

  {user_id}/addresses_id/ ;get



